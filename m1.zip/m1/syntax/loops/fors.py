# basic for loop in Python

def main():
    for i in range(10):
        print("i = ", i)


if __name__ == "__main__":
    main()
