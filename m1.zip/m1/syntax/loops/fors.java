// basic for loop in Java
package m1.syntax.loops;

public class fors {
    public static void main(String[] args) {
        // for loop
        for (int i = 0; i < 10; i++) {
            System.out.println("i = " + i);
        }
    }
}
