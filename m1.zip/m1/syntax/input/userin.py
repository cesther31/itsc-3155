# getting user input in Python

def main():
    name = input("Enter your name: ")
    print("Hello, " + name)


if __name__ == "__main__":
    main()
