// basic variable types in Java
package m1.syntax.variables;

public class variables {
    int myInt = 10; // an integer variable
    double myDouble = 20.5; // a floating point variable
    boolean myBool = true; // a boolean variable
    char myChar = 'A'; // a character variable
    String myString = "Hello"; // a string variable
}
