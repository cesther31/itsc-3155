# basic variable types in Python
def main():
    myInt = 0  # an integer
    myFloat = 0.0  # a floating point number
    myBool = True  # a boolean
    myChar = 'a'  # a string, which can be any length
    myString = "Hello World"  # a string, which can be any length


if __name__ == "__main__":
    main()
