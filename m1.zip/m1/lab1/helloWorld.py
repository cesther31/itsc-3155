def greet():
    # TODO 1: Finish this function's implementation
    # - print "Hello, World!" to the console
    pass  # Replace this line with your code


def main():
    greet()


if __name__ == '__main__':
    main()
